
const Collections = () => {
  return (
    <>
      <h2>Collections</h2>
    </>
  );
};

export default Collections;
