
const Offers = () => {
  return (
    <>
      <h2>Offers</h2>
    </>
  );
};

export default Offers;
